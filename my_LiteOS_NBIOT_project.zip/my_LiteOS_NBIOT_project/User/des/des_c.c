#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "des_h.h"
#include <stdbool.h>
#include "bsp_usart.h"
#include "./rtc/bsp_rtc.h"


const int IP[64]={ 58,50,42,34,26,18,10, 2,60,52,44,36,28,20,12, 4, 62,54,46,38,30,22,14, 6,64,56,48,40,32,24,16, 8, 57,49,41,33,25,17, 9, 1,59,51,43,35,27,19,11, 3, 61,53,45,37,29,21,13, 5,63,55,47,39,31,23,15, 7 };
const int IPR[64]={ 40, 8,48,16,56,24,64,32,39, 7,47,15,55,23,63,31, 38, 6,46,14,54,22,62,30,37, 5,45,13,53,21,61,29, 36, 4,44,12,52,20,60,28,35, 3,43,11,51,19,59,27, 34, 2,42,10,50,18,58,26,33, 1,41, 9,49,17,57,25	};
const int E[48]={ 32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9,10,11,12,13, 12,13,14,15,16,17, 16,17,18,19,20,21, 20,21,22,23,24,25, 24,25,26,27,28,29, 28,29,30,31,32, 1 };
const int PC1[56]={ 57,49,41,33,25,17, 9, 1,58,50,42,34,26,18, 10, 2,59,51,43,35,27,19,11, 3,60,52,44,36, 63,55,47,39,31,23,15, 7,62,54,46,38,30,22, 14, 6,61,53,45,37,29,21,13, 5,28,20,12, 4 };
const int LS[16]={ 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1 };
const int PC2[48]={ 14,17,11,24, 1, 5, 3,28,15, 6,21,10, 23,19,12, 4,26, 8,16, 7,27,20,13, 2, 41,52,31,37,47,55,30,40,51,45,33,48, 44,49,39,56,34,53,46,42,50,36,29,32	};
const int S_Box[8][4][16]={
 14, 4,13, 1, 2,15,11, 8, 3,10, 6,12, 5, 9, 0, 7, 0,15, 7, 4,14, 2,13, 1,10, 6,12,11, 9, 5, 3, 8, 4, 1,14, 8,13, 6, 2,11,15,12, 9, 7, 3,10, 5, 0, 15,12, 8, 2, 4, 9, 1, 7, 5,11, 3,14,10, 0, 6,13,
 15, 1, 8,14, 6,11, 3, 4, 9, 7, 2,13,12, 0, 5,10, 3,13, 4, 7,15, 2, 8,14,12, 0, 1,10, 6, 9,11, 5, 0,14, 7,11,10, 4,13, 1, 5, 8,12, 6, 9, 3, 2,15, 13, 8,10, 1, 3,15, 4, 2,11, 6, 7,12, 0, 5,14, 9,
 10, 0, 9,14, 6, 3,15, 5, 1,13,12, 7,11, 4, 2, 8, 13, 7, 0, 9, 3, 4, 6,10, 2, 8, 5,14,12,11,15, 1, 13, 6, 4, 9, 8,15, 3, 0,11, 1, 2,12, 5,10,14, 7, 1,10,13, 0, 6, 9, 8, 7, 4,15,14, 3,11, 5, 2,12,
 7,13,14, 3, 0, 6, 9,10, 1, 2, 8, 5,11,12, 4,15, 13, 8,11, 5, 6,15, 0, 3, 4, 7, 2,12, 1,10,14, 9, 10, 6, 9, 0,12,11, 7,13,15, 1, 3,14, 5, 2, 8, 4, 3,15, 0, 6,10, 1,13, 8, 9, 4, 5,11,12, 7, 2,14,
 2,12, 4, 1, 7,10,11, 6, 8, 5, 3,15,13, 0,14, 9, 14,11, 2,12, 4, 7,13, 1, 5, 0,15,10, 3, 9, 8, 6, 4, 2, 1,11,10,13, 7, 8,15, 9,12, 5, 6, 3, 0,14, 11, 8,12, 7, 1,14, 2,13, 6,15, 0, 9,10, 4, 5, 3,
 12, 1,10,15, 9, 2, 6, 8, 0,13, 3, 4,14, 7, 5,11, 10,15, 4, 2, 7,12, 9, 5, 6, 1,13,14, 0,11, 3, 8, 9,14,15, 5, 2, 8,12, 3, 7, 0, 4,10, 1,13,11, 6, 4, 3, 2,12, 9, 5,15,10,11,14, 1, 7, 6, 0, 8,13,
4,11, 2,14,15, 0, 8,13, 3,12, 9, 7, 5,10, 6, 1, 13, 0,11, 7, 4, 9, 1,10,14, 3, 5,12, 2,15, 8, 6, 1, 4,11,13,12, 3, 7,14,10,15, 6, 8, 0, 5, 9, 2, 6,11,13, 8, 1, 4,10, 7, 9, 5, 0,15,14, 2, 3,12,
 13, 2, 8, 4, 6,15,11, 1,10, 9, 3,14, 5, 0,12, 7, 1,15,13, 8,10, 3, 7, 4,12, 5, 6,11, 0,14, 9, 2, 7,11, 4, 1, 9,12,14, 2, 0, 6,10,13,15, 3, 5, 8, 2, 1,14, 7, 4,10, 8,13,15,12, 9, 0, 3, 5, 6,11


};
const int P[32]={ 16, 7,20,21,29,12,28,17, 1,15,23,26, 5,18,31,10, 2, 8,24,14,32,27, 3, 9,19,13,30, 6,22,11, 4,25 };
static bool SubKey[16][48]={0};




void Decrypt(bool *DecryptBit,bool CipherBit[64],bool KeyBit[64])
{
	static bool tmpCipher[64]={0};				//??,????CipherBit???CBC????????
	Table_change(tmpCipher,CipherBit,IP,64);	//IP????
	SetKey(KeyBit);
	static bool *CiL=&tmpCipher[0],*CiR=&tmpCipher[32];	//?????L,R??
	static bool Temp[32]={0};	//??
	for(int i=15;i>=0;i--)	//16???
	{
		BitCopy(Temp,CiR,32);
		F_change(CiR,CiR,i);
		Xor(CiR,CiL,32);
		BitCopy(CiL,Temp,32);
	}
	Reverse(CiL,CiR,32);
	Table_change(DecryptBit,tmpCipher,IPR,64); 	//?????
}

void Encrypt(bool *CipherBit,bool PlainBit[64],bool KeyBit[64])		//?????????
{ 
	
	static bool *PiL=0,*PiR=0;	//?????L,R??
	Table_change(PlainBit,PlainBit,IP,64);	//IP????
	SetKey(KeyBit);	//??16???
//	static bool *PiL=PlainBit[0],*PiR=&PlainBit[32];	//?????L,R??
	static bool Temp[32]={0};	//??
	PiL=&PlainBit[0]; PiR=&PlainBit[32];
	for(int i=0;i<16;i++)	//16???
	{
		BitCopy(Temp,PiR,32);
		F_change(PiR,PiR,i);
		Xor(PiR,PiL,32);
		BitCopy(PiL,Temp,32);
	}
	Reverse(PiL,PiR,32);
	Table_change(CipherBit,PlainBit,IPR,64); 	//?????
}

void Reverse(bool *Li,bool *Ri,int num)
{
	static bool temp[32]={0};
	int i;
	for (i=0;i<num;i++)
	{
		temp[i]=Li[i];
		Li[i]=Ri[i];
		Ri[i]=temp[i];
	}
}

void BitToHex(char *DatOut,bool *DatIn,int Num)
{
	int i=0,value;
	char tmp[100]={0};
	for(i=0;i<Num/4;i++)
	{
		value =((DatIn[i*4])<<3)+((DatIn[i*4+1])<<2)+((DatIn[i*4+2])<<1)+(DatIn[i*4+3]);
		if(value>9)
		{
			tmp[i]=value+'7';       //  ????9??? 10-15 to A-F
		}
		else
		{
			tmp[i]=value+'0';       //  ????
		}
	}
	strcpy(DatOut,tmp);

}

void F_change(bool *Out,bool *Ri_,int Num) 	//Num?????
{
	bool Temp[48]={0};
	Table_change(Temp,Ri_,E,48);	//E??
	Xor(Temp,SubKey[Num],48);
	S_change(Temp,Temp);	//S???
	Table_change(Out,Temp,P,32);	//P??
}
void S_change(bool *DatOut,bool *DatIn)	//??48?,??32?
{
	int i=0,X,Y;
	bool Temp[32]={0};
	for (i=0;i<8;i++)
	{

		Y=((DatIn[i*6])<<1)+(DatIn[i*6+5]);                          // Y?????,X?????
		X=((DatIn[i*6+1])<<3)+((DatIn[i*6+2])<<2)+((DatIn[i*6+3])<<1)+(DatIn[i*6+4]);	//??????????
		IntToBit(&Temp[i*4],S_Box[i][Y][X],4);	//??????????

	}
	BitCopy(DatOut,Temp,32);	//??
}

void IntToBit(bool *DatOut,int DatIn,int Num)
{
	int i=0;
	bool temp[64]={0};
	for(i=0;i<Num;i++)
	{
		temp[i]=(((DatIn)<<(i%4))&0x08);
	}
	BitCopy(DatOut,temp,Num);
}


void HexToBit(bool *DatOut,char *DatIn,int Num)
{
	int i=0;                        // ?????
	for(i=0;i<Num;i++)
	{

		if((DatIn[i/4])>'9')         //  ??9
		{
			DatOut[i]=((((DatIn[i/4]-'7')%16)<<(i%4))&0x08);
		}
		else
		{
			DatOut[i]=(((DatIn[i/4]-'0')<<(i%4))&0x08);
		}
	}
}

void Xor(bool *DatA,bool *DatB,int Num)           // ????
{
	int i=0;
	for(i=0;i<Num;i++)
	{
		DatA[i]=DatA[i]^DatB[i];                  // ??
	}
}

void SetKey(bool *KeyBit)
{
	bool Temp[56]={0};			//????,????KeyBit????????
	Table_change(Temp,KeyBit,PC1,56);
	bool *KiL=&Temp[0],*KiR=&Temp[28];
	for(int i=0;i<16;i++){
		LoopMove(KiL,28,LS[i]);
		LoopMove(KiR,28,LS[i]);
		Table_change(SubKey[i],Temp,PC2,48);
	}
}

void LoopMove(bool *DatIn,int Len,int num) // ???? Len???? Num????
{
	bool tmp[56]={0};    					// ??
	BitCopy(tmp,DatIn,num);
	BitCopy(DatIn,DatIn+num,Len-num);
	BitCopy(DatIn+Len-num,tmp,num);
}


void BitCopy(bool *DatOut,bool *DatIn,int Num)
{
	int i=0;
	for(i=0;i<Num;i++)
	{
		DatOut[i]=DatIn[i];
	}
}
void Table_change(bool *DatOut,bool *DatIn,const int *Table,int Num)
{
	static bool Tmp[256]={0};
	int i;
	for (i=0;i<Num;i++)
	{
		Tmp[i]=DatIn[Table[i]-1];	//??????????????Temp?
	}
	BitCopy(DatOut,Tmp,Num);       // ???Temp????
}
void CBC_encrypt(char *data_in,u8 *dataout)
{
//	char
	  char pt1[17]={0};
    char pt2[17]={0};
		u8 dian[5];
    char IV[]="696969696d6d6d6d";
    char data[]="11111111111111111111111111111111";
	  bool IVBit[64]={0};
		data[0]=zhuanhuan_tall(data_in);
		data[1]=zhuanhuan_low(data_in);
		data[2]=zhuanhuan_tall(&data_in[1]);
		data[3]=zhuanhuan_low(&data_in[1]);
		data[4]=zhuanhuan_tall(&data_in[2]);
		data[5]=zhuanhuan_low(&data_in[2]);
		data[6]=zhuanhuan_tall(&data_in[3]);
		data[7]=zhuanhuan_low(&data_in[3]);
		data[8]=zhuanhuan_tall(&data_in[4]);
		data[9]=zhuanhuan_low(&data_in[4]);
	 	data[10]=zhuanhuan_tall(&data_in[5]);
		data[11]=zhuanhuan_low(&data_in[5]);
		data[12]=zhuanhuan_tall(&data_in[6]);
		data[13]=zhuanhuan_low(&data_in[6]);
		data[14]=zhuanhuan_tall(&data_in[7]);
		data[15]=zhuanhuan_low(&data_in[7]);
		data[16]=zhuanhuan_tall(&data_in[8]);
		data[17]=zhuanhuan_low(&data_in[8]);
	 	data[18]=zhuanhuan_tall(&data_in[9]);
		data[19]=zhuanhuan_low(&data_in[9]);
		data[20]=zhuanhuan_tall(&data_in[10]);
		data[21]=zhuanhuan_low(&data_in[10]);
		data[22]=zhuanhuan_tall(&data_in[11]);
		data[23]=zhuanhuan_low(&data_in[11]);
		data[24]=zhuanhuan_tall(&data_in[12]);
		data[25]=zhuanhuan_low(&data_in[12]);
		data[26]=zhuanhuan_tall(&data_in[13]);
		data[27]=zhuanhuan_low(&data_in[13]);
	 	data[28]=zhuanhuan_tall(&data_in[14]);
		data[29]=zhuanhuan_low(&data_in[14]);
		data[30]=zhuanhuan_tall(&data_in[15]);
		data[31]=zhuanhuan_low(&data_in[15]);


		printf("data=%s\r\n",data);
	
	
	printf("IV:%s\r\n",IV);
	HexToBit(IVBit,IV,64);
    int length2=32;
    printf("length2:%d\r\n",length2);
	for(int j=0;j<((length2+15)/16);j++)   //?64bit???????, length??16?+15/16???????
	{
		char Plain[17]={'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};  //???0
		//char Key2[16]={0};		//??
		char Key[]="3132333461626344";		//??
		char Cipher[17]={0};	//??
		bool PlainBit[64]={0};	//?????
		bool CipherBit[64]={0}; //?????
		bool KeyBit[64]={0}; 	//?????
		int i=0;
		for(i=0;i<16;i++)
		{
       if(j==0)
			 Plain[i]=data[i];
			 if(j==1)
		  	Plain[i]=data[16+i];	 
		}
		
		
		HexToBit(PlainBit,Plain,64);	//?16???????????
	 // 	printf("Key:%s\r\n",Key);
		HexToBit(KeyBit,Key,64);				//?16???key?????
		Xor(PlainBit,IVBit,64);		//??M1?IV?? ??PlainBit
		Encrypt(CipherBit,PlainBit,KeyBit);		//????
		BitToHex(Cipher,CipherBit,64);			//?CipherBit??16??

               if(j==0)
       {
    
				  memcpy(pt1,Cipher,sizeof(Cipher));		
				  dataout[0]=chartohex_tall(&pt1[0])+chartohex_low(&pt1[1]);
				  dataout[1]=chartohex_tall(&pt1[2])+chartohex_low(&pt1[3]);
				  dataout[2]=chartohex_tall(&pt1[4])+chartohex_low(&pt1[5]);
				  dataout[3]=chartohex_tall(&pt1[6])+chartohex_low(&pt1[7]);
				  dataout[4]=chartohex_tall(&pt1[8])+chartohex_low(&pt1[9]);
				  dataout[5]=chartohex_tall(&pt1[10])+chartohex_low(&pt1[11]);
				  dataout[6]=chartohex_tall(&pt1[12])+chartohex_low(&pt1[13]);
				  dataout[7]=chartohex_tall(&pt1[14])+chartohex_low(&pt1[15]);
				 
//         printf("dataout:%x",dataout[0]);	
//			  printf("dataout:%x",dataout[1]);
//         printf("dataout:%x",dataout[2]);	
//							 printf("dataout:%x",dataout[3]);	
//					 printf("dataout:%x",dataout[4]);	
//				  printf("dataout:%x",dataout[5]);	
//				  printf("dataout:%x",dataout[6]);	
//				  printf("dataout:%x",dataout[7]);	
				 

       }
       else if (j==1)
       {
          // sprintf(pt2,"%s",Cipher);
				 memcpy(pt2,Cipher,sizeof(Cipher));	
    	   	dataout[8]=chartohex_tall(&pt2[0])+chartohex_low(&pt2[1]);
				  dataout[9]=chartohex_tall(&pt2[2])+chartohex_low(&pt2[3]);
				  dataout[10]=chartohex_tall(&pt2[4])+chartohex_low(&pt2[5]);
				  dataout[11]=chartohex_tall(&pt2[6])+chartohex_low(&pt2[7]);
				  dataout[12]=chartohex_tall(&pt2[8])+chartohex_low(&pt2[9]);
				  dataout[13]=chartohex_tall(&pt2[10])+chartohex_low(&pt2[11]);
				  dataout[14]=chartohex_tall(&pt2[12])+chartohex_low(&pt2[13]);
				  dataout[15]=chartohex_tall(&pt2[14])+chartohex_low(&pt2[15]);
//				 printf("dataout:%x",dataout[8]);	
//			  printf("dataout:%x",dataout[9]);
//         printf("dataout:%x",dataout[10]);	
//				 printf("dataout:%x",dataout[11]);	
//					 printf("dataout:%x",dataout[12]);	
//				  printf("dataout:%x",dataout[13]);	
//				  printf("dataout:%x",dataout[14]);	
//				  printf("dataout:%x",dataout[15]);	
       }
     		BitCopy(IVBit,CipherBit,64); 	//????CipherBit???IVBit,???????
     //   printf("Cipher:%s",Cipher);
		
	}
	     

          
}

void Data_for_DLT645(u8 *data_645,float data_reg, u8 size)
{
	
   u32   data2;
   u8   data3,t,fushu=0;


				data2 = data_reg;
				for(t =0;t<2;t++)
				{
					 data3 = data2%100;
					 *(data_645+t) = data3%10 +data3/10*16;
					 data2/=100;
				}
				*(data_645+1)|= ((fushu==1)?0x80:0x00);
				
	
	 
}