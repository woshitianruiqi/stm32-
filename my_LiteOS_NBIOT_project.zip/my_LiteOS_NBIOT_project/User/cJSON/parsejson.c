#include <stdio.h>
#include <stdlib.h>
#include "cJSON.h"
#include "wifi.h"	    //������Ҫ��ͷ�ļ�
#include "bsp_usart2.h"
#include "bsp_usart.h"
#include "parsejson.h"
#include "malloc.h"
//#include "usart3.h"
#include "string.h"
//#include "delay.h"
#include "weather.h"

//�����ַ���ת��������
static u8 str2int(u8 *str)
{
	u8 len,res;
	len = strlen((const char *)str);
	switch(len)
	{
		case 1:
			res = str[0]-0x30;
			break;
		case 2:
			res = (str[0]-0x30)*10+(str[1]-0x30);
			break;
		default:
			break;
	}
	return res;
}

u8 parse_now_weather(void)
{
	cJSON *root;
	cJSON *pSub;
	cJSON *pItem;

	char *utf8str;

	root = mymalloc(SRAMIN,sizeof(cJSON));
	pSub = mymalloc(SRAMIN,sizeof(cJSON));
	pItem = mymalloc(SRAMIN,sizeof(cJSON));

	utf8str = mymalloc(SRAMIN,50);

	memset(utf8str,0,50);

// printf("jieshou->1dayjson = %s\r\n",USART3_RX_BUF);
	
	printf("\r\n\r\n");
	printf("\r\n\r\n");
	
	
	root = cJSON_Parse((const char*)WiFi_RX_BUF);
	if(root != NULL)
	{
		pSub = cJSON_GetObjectItem(root,"result");
		if(pSub != NULL)
		{
			pItem = cJSON_GetObjectItem(pSub,"datetime_1");
			if(pItem != NULL)
			{
				utf8str = pItem->valuestring;
				// 2019-05-07 18:23:26
				nwt.year = (utf8str[2]-0x30)*10+(utf8str[3]-0x30);
				nwt.month = (utf8str[5]-0x30)*10+(utf8str[6]-0x30);
				nwt.date = (utf8str[8]-0x30)*10+(utf8str[9]-0x30);
				
				nwt.hour = (utf8str[11]-0x30)*10+(utf8str[12]-0x30);
				nwt.min = (utf8str[14]-0x30)*10+(utf8str[15]-0x30);
				nwt.sec = (utf8str[17]-0x30)*10+(utf8str[18]-0x30);
				printf("%s\r\n",utf8str);
			}
		}
	}
	cJSON_Delete(root);
	myfree(SRAMIN,root);
	cJSON_Delete(pSub);
	myfree(SRAMIN,pSub);
	cJSON_Delete(pItem);
	myfree(SRAMIN,pItem);

	myfree(SRAMIN,utf8str);
	return 0;
}
