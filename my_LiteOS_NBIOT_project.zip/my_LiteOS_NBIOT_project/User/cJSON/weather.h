#ifndef __WEATHER_H
#define __WEATHER_H
#include "stm32f10x.h"
//#include "sys.h"

u8 get_current_weather(void);
u8 get_3days_weather(void);
void show_weather(void);

u8 get_beijing_time(void);

typedef struct   //�ṹ�塣
{
    vu16  year;
    vu8   month;
    vu8   date;
    vu8   hour;
    vu8   min;
    vu8   sec;	 
}nt_calendar_obj;

//����ṹ�����
extern nt_calendar_obj nwt;  //����ṹ�����

#endif


