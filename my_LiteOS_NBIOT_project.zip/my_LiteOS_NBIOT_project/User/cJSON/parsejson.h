#ifndef __PARSEJSON_
#define __PARSEJSON_
#include "stm32f10x.h"
//#include "sys.h"

uint8_t parse_3days_weather(void);
uint8_t parse_now_weather(void);

#endif



