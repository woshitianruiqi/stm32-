#ifndef __ch9329_H
#define __ch9329_H

#include "stm32f10x.h"
#include "stdio.h"	

//#include "sys.h" 
//#include "delay.h"
 /* LiteOS ͷ�ļ� */
#include "los_sys.h"
#include "los_task.ph"
#include "los_queue.h"
#include "los_sem.h"
#include "los_swtmr.h"


void Usart_SendByte3( USART_TypeDef * pUSARTx, uint8_t data);	

void SUM(void);
void Coordinates(void);
void SEND_MS_ABS_DATA(int X, int Y);
void  ASCII_Hiddata(char ascii);	

void SEND_KB(void);
void SEND_MS_ABS(void);
void SEND_MS_KB(void);

void setwindowprogram_chinese(const unsigned char *BMP);
 void implement( char *BMP);     //ִ���Զ���������
void delay_S(int n);                               //ϵͳ�����ʱ
  void ONE_implement_move(const unsigned char *BMP);//����һ��


#endif


